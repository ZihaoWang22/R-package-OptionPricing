#Binary Tree Plot of Put Option 
Bitreeplot_Put <- function(S0, K, T, r, q, sigma, N) {
  result_total <- Bitree_Put(S0, K, T, r, q, sigma, N)
  N_right <- N+0.5
  n_step <- nrow(result_total) - 1
  f <- c()
  N <- c()
  tag_S <- c()
  tag_f <- c()
  Price <- c()
  for(i in 1:n_step){
    for(j in 1:i){
      Y_seq <- seq(from = -i+1,by = 2, length = i)
      Price <- c(Price,3*(n_step+Y_seq[j]))
      f <- c(f,result_total[j,i+1])
      N <- c(N,i-1)
      tag_S <- c(tag_S,round(result_total[i+1,j],2))
      tag_f <- c(tag_f,round(result_total[j,i+1],2))
    }
  }
  par(pin = c(4.4,4.4))
  plot(N,Price,xlim = c(-0.5,N_right-0.5) ,ylim = c(0,max(Price)+2),pch = 20,axes = FALSE,xlab = " ",ylab = " ")
  title("Binary Tree Plot of Put Option ")
  text(N,Price,tag_S,cex=0.6, pos=3, col="blue")
  text(N,Price,tag_f,cex=0.6, pos=1, col="red")
  legend("bottomleft",legend = c("Stock Price","Option Price"),pch = 20,col = c("blue","red"),bty = "n")
  for(i in 1:n_step){
    for(j in 1:i){
      arrows(x0 = N[0.5*(i*i-i)+j], y0 = Price[0.5*(i*i-i)+j], x1 = N[0.5*(i*i+i)+1], y1 = Price[0.5*((i+1)*(i+1)-i)+j], code = 2,length = 0.06)
      arrows(x0 = N[0.5*(i*i-i)+j], y0 = Price[0.5*(i*i-i)+j], x1 = N[0.5*(i*i+i)+1], y1 = Price[0.5*((i+1)*(i+1)-i)+j+1], code = 2,length = 0.06)
    }
  }
}

#Binary Tree Plot of Call Option 
Bitreeplot_Call <- function(S0, K, T, r, q, sigma, N) {
  result_total <- Bitree_Call(S0, K, T, r, q, sigma, N)
  N_right <- N+0.5
  n_step <- nrow(result_total) - 1
  f <- c()
  N <- c()
  tag_S <- c()
  tag_f <- c()
  Price <- c()
  for(i in 1:n_step){
    for(j in 1:i){
      Y_seq <- seq(from = -i+1,by = 2, length = i)
      Price <- c(Price,3*(n_step+Y_seq[j]))
      f <- c(f,result_total[j,i+1])
      N <- c(N,i-1)
      tag_S <- c(tag_S,round(result_total[i+1,j],2))
      tag_f <- c(tag_f,round(result_total[j,i+1],2))
    }
  }
  par(pin = c(4.4,4.4))
  plot(N,Price,xlim = c(-0.5,N_right-0.5) ,ylim = c(0,max(Price)+2),pch = 20,axes = FALSE,xlab = " ",ylab = " ")
  title("Binary Tree Plot of Call Option ")
  text(N,Price,tag_S,cex=0.6, pos=3, col="blue")
  text(N,Price,tag_f,cex=0.6, pos=1, col="red")
  legend("bottomleft",legend = c("Stock Price","Option Price"),pch = 20,col = c("blue","red"),bty = "n")
  for(i in 1:n_step){
    for(j in 1:i){
      arrows(x0 = N[0.5*(i*i-i)+j], y0 = Price[0.5*(i*i-i)+j], x1 = N[0.5*(i*i+i)+1], y1 = Price[0.5*((i+1)*(i+1)-i)+j], code = 2,length = 0.06)
      arrows(x0 = N[0.5*(i*i-i)+j], y0 = Price[0.5*(i*i-i)+j], x1 = N[0.5*(i*i+i)+1], y1 = Price[0.5*((i+1)*(i+1)-i)+j+1], code = 2,length = 0.06)
    }
  }
}