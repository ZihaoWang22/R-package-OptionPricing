#include <cmath>
#include <random>
#include <chrono>
#include <vector>
#include <RcppArmadillo.h>
#include <Rcpp.h>

// [[Rcpp::depends(RcppArmadillo)]]
//' compute cumulated distribution function of standard normal distribution
//' 
//' @param x: value to count standard normal distribution cdf
// [[Rcpp::export]]
double cdfnorm(double x)
{
  return 0.5 * (1 + std::erf(x / std::sqrt(2)));
}

//' use Black-Scholes Model to compute European call option price
//' 
//' @param S0: stock price
//' @param K: strike price
//' @param T: spot time
//' @param r: risk-free interest rate
//' @param q: dividend rate
//' @param sigma: stock volatility
//' @return European call option price by Black-Scholes Model
//' @examples
//' library(OptionPricing)
//' StockPrice = 50
//' StrikePrice = 50
//' SpotTime = 0.4167
//' RiskFreeRate = 0.1
//' DividendRate = 0.02
//' Sigma = 0.4
//' EuropeanCallPrice = European_Call(StockPrice, StrikePrice, SpotTime, RiskFreeRate, DividendRate, Sigma)
// [[Rcpp::export]]
double European_Call(double S0, double K,double T, double r, double q, double sigma)
{
  double d1 = (std::log(S0/K)+((r-q)+sigma*sigma/2)*T)/(sigma*std::sqrt(T));
  double d2 = d1 - sigma*std::sqrt(T);
  return S0*cdfnorm(d1)-K*std::exp(-(r-q)*T)*cdfnorm(d2);
}

//' use Black-Scholes Model to compute European put option price
//' 
//' @param S0: stock price
//' @param K: strike price
//' @param T: spot time
//' @param r: risk-free interest rate
//' @param q: dividend rate
//' @param sigma: stock volatility
//' @return European put option price by Black-Scholes Model
//' @examples
//' library(OptionPricing)
//' StockPrice = 50
//' StrikePrice = 50
//' SpotTime = 0.4167
//' RiskFreeRate = 0.1
//' DividendRate = 0.02
//' Sigma = 0.4
//' EuropeanPutPrice = European_Put(StockPrice, StrikePrice, SpotTime, RiskFreeRate, DividendRate, Sigma)
// [[Rcpp::export]]
double European_Put(double S0, double K, double T,double r, double q, double sigma)
{
  double d1 = (std::log(S0/K)+((r-q)+sigma*sigma/2)*T)/(sigma*std::sqrt(T));
  double d2 = d1 - sigma*std::sqrt(T);
  
  return K*std::exp(-(r-q)*T)*cdfnorm(-d2)-S0*cdfnorm(-d1);
}

//'use Monte Carlo method to compute American option call price
//'
//' @param S0: stock price
//' @param K: strike price
//' @param T: spot time
//' @param r: risk-free interest rate
//' @param q: dividend rate
//' @param sigma: stock volatility
//' @param N: Monte Carlo iteration times
//' @return American call option price by Monte Carlo method
//' @examples
//' library(OptionPricing)
//' StockPrice = 50
//' StrikePrice = 50
//' SpotTime = 0.4167
//' RiskFreeRate = 0.1
//' DividendRate = 0.02
//' Sigma = 0.4
//' N = 100
//' MonteCarloCallOption = MonteCarlo_Call(StockPrice, StrikePrice, SpotTime, RiskFreeRate, DividendRate, Sigma, N)
// [[Rcpp::export]]
double MonteCarlo_Call(double S0, double K, double T,double r, double q, double sigma, int N)
{
  unsigned seed = std::chrono::system_clock::now().time_since_epoch().count();
  
  std::default_random_engine gen(seed);
  double sumOpCall=0.0;
  for(int i(0); i<N; ++i)
  {
    std::normal_distribution<double> dis(0,1);
    sumOpCall += std::exp(-(r-q)*T)*std::max(S0*exp(((r-q)-sigma*sigma/2)*T + sigma*dis(gen)*std::sqrt(T))-K,0.0);
  }
  return sumOpCall/N;
}
//'use Monte Carlo method to compute American option put price
//'
//' @param S0: stock price
//' @param K: strike price
//' @param T: spot time
//' @param r: risk-free interest rate
//' @param q: dividend rate
//' @param sigma: stock volatility
//' @param N: Monte Carlo iteration
//' @return American put option price by Monte Carlo method
//' @examples
//' library(OptionPricing)
//' StockPrice = 50
//' StrikePrice = 50
//' SpotTime = 0.4167
//' RiskFreeRate = 0.1
//' DividendRate = 0.02
//' Sigma = 0.4
//' N = 100
//' MonteCarloPutOption = MonteCarlo_Put(StockPrice, StrikePrice, SpotTime, RiskFreeRate, DividendRate, Sigma, N)
// [[Rcpp::export]]
double MonteCarlo_Put(double S0, double K, double T,double r, double q, double sigma, int N)
{
  unsigned seed = std::chrono::system_clock::now().time_since_epoch().count();
  
  std::default_random_engine gen(seed);
  double sumOpPut=0.0;
  for(int i(0); i<N; ++i)
  {
    std::normal_distribution<double> dis(0,1);
    sumOpPut += std::exp(-(r-q)*T)*std::max(K-S0*std::exp(((r-q)-sigma*sigma/2)*T + sigma*dis(gen)*std::sqrt(T)),0.0);
  }
  return sumOpPut/N;
}

//' use Binary Tree method to compute American option call price
//' 
//' @param S0: stock price
//' @param K: strike price
//' @param T: spot time
//' @param r: risk-free interest rate
//' @param q: dividend rate
//' @param sigma: stock volatility
//' @param N: time step of binary tree
//' @return Binary Tree matrix of American call option, lower triangle is stock price binary tree, upper triangle is option price binary tree
//' @examples
//' library(OptionPricing)
//' StockPrice = 50
//' StrikePrice = 50
//' SpotTime = 0.4167
//' RiskFreeRate = 0.1
//' DividendRate = 0.02
//' Sigma = 0.4
//' N = 10
//' BinaryTreeMatrixCall = Bitree_Call(StockPrice, StrikePrice, SpotTime, RiskFreeRate, DividendRate, Sigma, N)
// [[Rcpp::export]]
arma::mat Bitree_Call(double S0, double K, double T, double r, double q, double sigma, int N) 
{
  arma::mat S(N+1,N+1);
  double u=std::exp(sigma*sqrt(T/(N-1)));
  double d=std::exp(-sigma*sqrt(T/(N-1)));
  double a=std::exp((r-q)*(T/(N-1)));
  double p=(a-d)/(u-d);
  int i,j;
  for(i=1; i<=N; i++){
    for(j=0; j<=i-1; j++){
      S(i,j)=S0*std::pow(u,j)*std::pow(d,i-j-1);
    }
  }
  for(i=N-1; i>=0; i--){
    S(i,N)=std::max(S(N,i)-K,0.0);
  }
  for(j=N-1; j>=1; j--){
    for(i=j-1; i>=0; i--){
      S(i,j)=std::max(S(j,i)-K,std::exp(-(r-q)*(T/(N-1)))*(p*S(i+1,j+1)+(1-p)*S(i,j+1)));
    }
  }
  return S;
}

//' use Binary Tree method to compute American option put price
//' @param S0: stock price
//' @param K: strike price
//' @param T: spot time
//' @param r: risk-free interest rate
//' @param q: dividend rate
//' @param sigma: stock volatility
//' @param N: time step of binary tree
//' @return Binary Tree matrix of American put option, lower triangle is stock price binary tree, upper triangle is option price binary tree
//' @examples
//' library(OptionPricing)
//' StockPrice = 50
//' StrikePrice = 50
//' SpotTime = 0.4167
//' RiskFreeRate = 0.1
//' DividendRate = 0.02
//' Sigma = 0.4
//' N = 10
//' BinaryTreeMatrixPut = Bitree_Put(StockPrice, StrikePrice, SpotTime, RiskFreeRate, DividendRate, Sigma, N)
// [[Rcpp::export]]
arma::mat Bitree_Put(double S0, double K, double T, double r, double q, double sigma, int N) 
{
  arma::mat S(N+1,N+1);
  double u=std::exp(sigma*sqrt(T/(N-1)));
  double d=std::exp(-sigma*sqrt(T/(N-1)));
  double a=std::exp((r-q)*(T/(N-1)));
  double p=(a-d)/(u-d);
  int i,j;
  for(i=1; i<=N; i++){
    for(j=0; j<=i-1; j++){
      S(i,j)=S0*std::pow(u,j)*std::pow(d,i-j-1);
    }
  }
  for(i=N-1; i>=0; i--){
    S(i,N)=std::max(-S(N,i)+K,0.0);
  }
  for(j=N-1; j>=1; j--){
    for(i=j-1; i>=0; i--){
      S(i,j)=std::max(-S(j,i)+K,std::exp(-(r-q)*(T/(N-1)))*(p*S(i+1,j+1)+(1-p)*S(i,j+1)));
    }
  }
  return S;
}

//'use finite difference implicit method to compute American option put price
//'
//' @param S0: stock price
//' @param K: strike price
//' @param T: spot time
//' @param r: risk-free interest rate
//' @param q: dividend rate
//' @param sigma: stock volatility
//' @param N: time step of finite difference
//' @param delts: time step size of finite difference
//' @return put option result matrix of finite difference implicit method
//' @examples
//' library(OptionPricing)
//' StockPrice = 50
//' StrikePrice = 50
//' SpotTime = 0.4167
//' RiskFreeRate = 0.1
//' DividendRate = 0.02
//' Sigma = 0.4
//' N = 10
//' delts = 5
//' FDImMatrixPut = FD_Implicit_Put(StockPrice, StrikePrice, SpotTime, RiskFreeRate, DividendRate, Sigma, N, delts)
// [[Rcpp::export]]
arma::mat FD_Implicit_Put(double S0, double K, double T, double r, double q, double sigma, int N, double delts)
{
  int Smax = floor(2*S0); 
  double delta_S = delts;
  int M = Smax/delta_S;
  arma::mat Option_result(M+1,N+1);
  
  for(int j = 0; j <= N; j++){
    Option_result(M,j) = K;
    Option_result(0,j) = 0.0;
  }
  for(int i = 0; i <= M; i++){
    Option_result(i,N) = std::max(K-(M-i)*delta_S,0.0);
  }
  arma::vec a(M-1,arma::fill::zeros);
  arma::vec b(M-1,arma::fill::zeros);
  arma::vec c(M-1,arma::fill::zeros);
  for(int k = 1; k <= M-1; k++){
    a(k-1) = 0.5*(r-q)*k*(T/N)-0.5*sigma*sigma*k*k*(T/N);
    b(k-1) = 1+sigma*sigma*k*k*(T/N)+r*(T/N);
    c(k-1) = -0.5*(r-q)*k*(T/N)-0.5*sigma*sigma*k*k*(T/N);
  }
  arma::mat coef(M+1,M+1,arma::fill::zeros);
  coef(0,0)=1;
  coef(M,M)=1;
  for(int i = 1; i < M; i++){
    coef(i,i-1) = a(i-1);
    coef(i,i) = b(i-1);
    coef(i,i+1) = c(i-1);
  }
  arma::vec y(M+1,arma::fill::zeros);
  for(int k = N; k > 0; k--){
    y = Option_result.col(k);
    Option_result.col(k-1) = arma::solve(coef,y);
  }
  return Option_result;
}

//'use finite difference implicit method to compute American option call price
//'
//' @param S0: stock price
//' @param K: strike price
//' @param T: spot time
//' @param r: risk-free interest rate
//' @param q: dividend rate
//' @param sigma: stock volatility
//' @param N: time step of finite difference
//' @param delts: time step size of finite difference
//' @return call option result matrix of finite difference implicit method
//' @examples
//' library(OptionPricing)
//' StockPrice = 50
//' StrikePrice = 50
//' SpotTime = 0.4167
//' RiskFreeRate = 0.1
//' DividendRate = 0.02
//' Sigma = 0.4
//' N = 10
//' delts = 5
//' FDImMatrixCall = FD_Implicit_Call(StockPrice, StrikePrice, SpotTime, RiskFreeRate, DividendRate, Sigma, N, delts)
// [[Rcpp::export]]
arma::mat FD_Implicit_Call(double S0, double K, double T, double r, double q, double sigma, int N, double delts)
{
  int Smax = floor(2*S0); 
  double delta_S = delts;
  int M = Smax/delta_S;
  arma::mat Option_result(M+1,N+1);
  
  for(int j = 0; j <= N; j++){
    Option_result(M,j) = 0.0;
    Option_result(0,j) = Smax-K;
  }
  for(int i = 0; i <= M; i++){
    Option_result(i,N) = std::max((M-i)*delta_S-K,0.0);
  }
  arma::vec a(M-1,arma::fill::zeros);
  arma::vec b(M-1,arma::fill::zeros);
  arma::vec c(M-1,arma::fill::zeros);
  for(int k = 1; k <= M-1; k++){
    a(k-1) = 0.5*(r-q)*k*(T/N)-0.5*sigma*sigma*k*k*(T/N);
    b(k-1) = 1+sigma*sigma*k*k*(T/N)+r*(T/N);
    c(k-1) = -0.5*(r-q)*k*(T/N)-0.5*sigma*sigma*k*k*(T/N);
  }
  arma::mat coef(M+1,M+1,arma::fill::zeros);
  coef(0,0)=1;
  coef(M,M)=1;
  for(int i = 1; i < M; i++){
    coef(i,i-1) = a(i-1);
    coef(i,i) = b(i-1);
    coef(i,i+1) = c(i-1);
  }
  arma::vec y(M+1,arma::fill::zeros);
  for(int k = N; k > 0; k--){
    y = Option_result.col(k);
    Option_result.col(k-1) = arma::solve(coef,y);
  }
  return Option_result;
}

//'use finite difference explicit method to compute American option put price
//'
//' @param S0: stock price
//' @param K: strike price
//' @param T: spot time
//' @param r: risk-free interest rate
//' @param q: dividend rate
//' @param sigma: stock volatility
//' @param N: time step of finite difference
//' @param delts: time step size of finite difference
//' @return put option result matrix of finite difference explicit method
//' @examples
//' library(OptionPricing)
//' StockPrice = 50
//' StrikePrice = 50
//' SpotTime = 0.4167
//' RiskFreeRate = 0.1
//' DividendRate = 0.02
//' Sigma = 0.4
//' N = 20
//' delts = 5
//' FDExMatrixPut = FD_Explicit_Put(StockPrice, StrikePrice, SpotTime, RiskFreeRate, DividendRate, Sigma, N, delts)
// [[Rcpp::export]]
arma::mat FD_Explicit_Put(double S0, double K, double T, double r, double q, double sigma, int N, double delts)
{
  int Smax = floor(2*S0);
  double delta_S = delts;
  int M=Smax/delta_S;
  arma::mat Option_result(M+1,N+1);
  for(int j = 0; j <= N; j++){
    Option_result(M,j) = K;
    Option_result(0,j) = 0.0;
  }
  for(int i = 1; i <= M-1; i++){
    Option_result(i,N) = std::max(K-(M-i)*delta_S ,0.0);
  }
  for(int j = N-1; j >=0 ; j--){
    for(int i = 1; i <= M -1; i++){
      double a = 1/(1+r*(T/N))*(-0.5*(r-q)*(M-i)*(T/N) + 0.5*(T/N)*sigma*sigma*(M-i)*(M-i));
      double b = 1/(1+r*(T/N))*(1-(T/N)*sigma*sigma*(M-i)*(M-i));
      double c = 1/(1+r*(T/N))*((T/N)*0.5*(r-q)*(M-i) + 0.5*(T/N)*sigma*sigma*(M-i)*(M-i));
      Option_result(i,j)= a*Option_result(i+1,j+1) + b*Option_result(i,j+1) + c*Option_result(i-1,j+1);
      
    }
  }
  return Option_result;
}

//'use finite difference explicit method to compute American option put price
//'
//' @param S0: stock price
//' @param K: strike price
//' @param T: spot time
//' @param r: risk-free interest rate
//' @param q: dividend rate
//' @param sigma: stock volatility
//' @param N: time step of finite difference
//' @param delts: time step size of finite difference
//' @return call option result matrix of finite difference explicit method
//' @examples
//' library(OptionPricing)
//' StockPrice = 50
//' StrikePrice = 50
//' SpotTime = 0.4167
//' RiskFreeRate = 0.1
//' DividendRate = 0.02
//' Sigma = 0.4
//' N = 20
//' delts = 5
//' FDExMatrixCall = FD_Explicit_Put(StockPrice, StrikePrice, SpotTime, RiskFreeRate, DividendRate, Sigma, N, delts)
// [[Rcpp::export]]
arma::mat FD_Explicit_Call(double S0, double K, double T, double r, double q, double sigma, int N, double delts){
  int Smax = floor(2*S0); 
  double delta_S = delts;
  int M=Smax/delta_S;
  arma::mat Option_result(M+1,N+1);
  for(int j = 0; j <= N; j++){
    Option_result(M,j) = 0.0;
    Option_result(0,j) = Smax-K;
  }
  for(int i = 1; i <= M-1; i++){
    Option_result(i,N) = std::max((M-i)*delta_S-K ,0.0);
  }
  for(int j = N-1; j >=0 ; j--){
    for(int i = 1; i <= M -1; i++){
      double a = 1/(1+r*(T/N))*(-0.5*(r-q)*(M-i)*(T/N) + 0.5*(T/N)*sigma*sigma*(M-i)*(M-i));
      double b = 1/(1+r*(T/N))*(1-(T/N)*sigma*sigma*(M-i)*(M-i));
      double c = 1/(1+r*(T/N))*((T/N)*0.5*(r-q)*(M-i) + 0.5*(T/N)*sigma*sigma*(M-i)*(M-i));
      Option_result(i,j)= a*Option_result(i+1,j+1) + b*Option_result(i,j+1) + c*Option_result(i-1,j+1);
    }
  }
  return Option_result;
}
